import java.util.ArrayList;

import iiitb.ess201a7.a7base.*;

public class Platform {

// all the methods in this class need to be implemented

	public Platform() {

	}

	public void addFleet(Fleet f) {

	}

	// for a request defined as a Trip, find the best car by checking each of its fleets
	// and assigns the car to this trip
	public Car assignCar(Trip trip) {

	}

	// returns list of all cars (in all the fleets) managed by this platform
	public ArrayList<Car> findCars() {

	}
}
