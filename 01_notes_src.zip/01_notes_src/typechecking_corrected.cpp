// typechecking_corrected.cpp

#include <iostream>
int main() {
  std :: cout << "Strict type checking" << std :: endl ;
  //return ;
   return 1 ;
}
