// typechecking.c

int main() {
  printf("Hello World\n");
  return ;
}
