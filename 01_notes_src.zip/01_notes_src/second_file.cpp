// second_file.cpp

#include <iostream>

void showints(int a = 0, int b = 1) {
  std :: cout << a << " and " << b << std :: endl ;
  return ;
}

