// typechecking.cpp

int main() {
  std :: cout << "Strict type checking " << std :: endl ;
  return ;
}
