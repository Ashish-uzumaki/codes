// mathtest.c

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

int main() {
  printf("Exponential function %f \n", exp(2.3));
  printf("Power function %f \n", pow(2,3));
}
