// default_func_parameters_variant2.cpp

#include <iostream>

extern void showints(int,int) ;

int main() {
  showints(1,0);
  showints();

  return 0 ;
}
