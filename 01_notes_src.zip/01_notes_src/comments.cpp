// comments.cpp

int main() {
// this is end-of-line comment
// one comment per line
/*
this is standard-C comment, covering
multiple lines
*/
}
