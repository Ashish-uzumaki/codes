// mathtest.cpp

#include <iostream>
#include <cmath>

int main() {
  std :: cout << "Exponential function " << exp(2.3) << std :: endl
	      << "Power function " << pow(2,3) << std :: endl ;
  return 0 ;
}
